<?php $__env->startSection('title', 'Page Title'); ?>

<?php $__env->startSection('css'); ?>
<style>
.card {
float: left!important;
    width: 80% !important;
    } 
    .form-control{
        text-align: right;
    }</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



    <div class="card bg-secondary shadow">
            <div class="card-header bg-white border-0">
              <div class="row align-items-center">
                <div class="col-8">
                  
                </div>
                <div class="col-4 text-right">
                 
                </div>
              </div>
            </div>
            <div class="card-body">
            <div class="panel-body">
                        <?php if($errors->count() > 0): ?>
                            <div class="alert alert-danger">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                        <form class="form-horizontal" method="POST" enctype="multipart/form-data">
                            <fieldset>
                            
                                <?php echo e(csrf_field()); ?>

                                
                <h6 class="heading-small text-muted mb-4" style=" text-align: right;">معلومات المستخدم</h6>
                <div class="pl-lg-4">
                  <div class="row" style=" text-align: right;">
                    
                    <div class="col-lg-6">
                      <div class="form-group">
                        <label class="form-control-label" for="input-email">العمر</label>
                        <input type="text" id="input-email" name="age" style=" text-align: right;" class="form-control form-control-alternative" placeholder="22">
                      </div>
                    </div>
                    <div class="col-lg-6" style=" text-align: right;">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-username">الاسم</label>
                        <input type="text" id="input-username" name="name" style=" text-align: right;" class="form-control form-control-alternative" placeholder="اسم الموظف" >
                      </div>
                    </div>
                  </div>
                  <div class="row" style=" text-align: right;">
                    
                    <div class="col-lg-6">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-last-name">القسم</label>
                        <select class="form-control" id="categories" style=" text-align: right;" name="categories">
                                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($category->id); ?>">
                                                    <?php echo e($category->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                      </div>
                    </div>
                    <div class="col-lg-6">
                      <div class="form-group focused">
                        <label class="form-control-label" for="input-first-name">الوظيفة</label>
                        <input type="text" id="input-first-name" style=" text-align: right;" name="job" class="form-control form-control-alternative" placeholder="الوظيفة" >
                      </div>
                    </div>
                  </div>
                </div>
                <hr class="my-4">
                <!-- Address -->
                <div class="form-group">
                                    <div class="col-lg-10" style=" text-align: right;">
                                       
                                        <button type="reset" class="btn btn-danger">
                                            <span class="fa fa-remove"></span>
                                            <span>الغاء</span>
                                        </button> 
                                        <button type="Submit" class="btn btn-primary">
                                            <span class="fa fa-plus"></span>
                                            <span>اضافة</span>
                                        </button>
                                    </div>
                                </div>
                </fieldset>
              </form>
            </div>
          </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>