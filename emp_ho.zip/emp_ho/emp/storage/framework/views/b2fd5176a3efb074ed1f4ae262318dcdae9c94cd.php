<?php $__env->startSection('title'); ?>
   emp
<?php $__env->stopSection(); ?>

<?php $__env->startSection('news'); ?>
   
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
.row {
float: left!important;
    width: 80% !important;
    direction: rtl;
    } 
    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    

             


    <div class="row">
        <div class="col">
          <div class="card shadow">
            <div class="card-header border-0">
              <h3 class="mb-0" style=" text-align: right;">الموظفين</h3>
            </div>
            <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <th scope="col">الاسم</th>
                    <th scope="col">العمر</th>
                    <th scope="col">الوظيفة</th>
                    <th scope="col">القسم</th>
                   
                    <th scope="col">تاريخ</th>
                    <th scope="col"></th>
                  </tr>
                </thead>
                <tbody>
                 
                      <div class="media align-items-center">

                      <?php $__currentLoopData = $em; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="media-body">
                          <span class="mb-0 text-sm"></span>
                        </div>
                      </div>
                    </th>
                    <td>
                    <?php echo e($item->name); ?>

                    </td>
                    <td>
                     <?php echo e($item->age); ?>

                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        <i></i> <?php echo e($item->job); ?>

                      </span>
                    </td>
                    <td>
                      <div class="avatar-group">
                       <span><?php echo e($item->Department->name); ?></span>
                       
                      </div>
                    </td>
                    <td>
                      <div class="d-flex align-items-center">
                        <span ><?php echo e($item->created_at->toDateString()); ?></span>
                        <div>
                          
                        </div>
                      </div>
                    </td>
                    <td class="text-right">
                      <div >
                      <a class="btn btn-danger" href="/admin/emplo/delete/<?php echo e($item->id); ?>">
                                        <span class="fa fa-remove"></span>
                                        <b>حذف</b>
                                    </a>
                                    <a class="btn btn-primary" href="/admin/emplo/edit/<?php echo e($item->id); ?>">
                                        <span class="fa fa-edit"></span>
                                        <b>تعديل </b>
                                    </a>
                        </div>
                      </div>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
            <div class="card-footer py-4">
            <div class="text-center">
                            <?php echo e($em->links()); ?>

                        </div>
            </div>
            <div class="form-group">
                                    <div class="col-lg-10" style=" text-align: right;">
                                       
                                       
                                   <button type="Submit" class="btn btn-primary">
                                            <span class="fa fa-plus"></span>
                                         <a href="/admin/emplo/add" class="btn btn-info">     <span>اضافة موظف</span>
                                       </a> </button>
                                    </div>
                                </div>
          </div>
        </div>
      </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>