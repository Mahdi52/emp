@extends('layouts.master')

@section('title')
   emp
@endsection

@section('news')
   
@endsection

@section('css')
<style>
.row {
float: left!important;
    width: 80% !important;
    direction: rtl;
    } 
    </style>
@endsection
@section('content')
    

             


    <div class="row">
        <div class="col">
          <div class="card shadow">
            <div class="card-header border-0">
              <h3 class="mb-0" style=" text-align: right;"> اجازات الموظفين</h3>
            </div>
            <div class="table-responsive">
              <table class="table align-items-center table-flush">
                <thead class="thead-light">
                  <tr>
                    <th scope="col">الاسم</th>
                    <th scope="col">المدة</th>
                    <th scope="col">نوع الاجازة</th>
                    <th scope="col"></th>
                   
                    <th scope="col">تاريخ</th>
                    <th scope="col"></th>
                  </tr>
                </thead>
                <tbody>
                 
                      <div class="media align-items-center">

                      @foreach($em as $item)
                        <div class="media-body">
                          <span class="mb-0 text-sm"></span>
                        </div>
                      </div>
                    </th>
                    <td>
                    {{ $item->name }}
                    </td>
                    <td>
                     {{ $item->time1 }}
                    </td>
                    <td>
                      <span class="badge badge-dot mr-4">
                        <i></i> {{ $item->holiday->type }}
                      </span>
                    </td>
                    <td>
                      <div class="avatar-group">
                     
                       
                      </div>
                    </td>
                    <td>
                      <div class="d-flex align-items-center">
                        <span >{{ $item->created_at->toDateString() }}</span>
                        <div>
                          
                        </div>
                      </div>
                    </td>
                    <td class="text-right">
                      <div >
                      <a class="btn btn-danger" href="/admin/emp_hoilday/delete/{{ $item->id }}">
                                        <span class="fa fa-remove"></span>
                                        <b>حذف</b>
                                    </a>
                                    <a class="btn btn-primary" href="/admin/emp_hoilday/edit/{{ $item->id }}">
                                        <span class="fa fa-edit"></span>
                                        <b>تعديل </b>
                                    </a>
                        </div>
                      </div>
                    </td>
                  </tr>
                  @endforeach
                </tbody>
              </table>
            </div>
            <div class="card-footer py-4">
            <div class="text-center">
                            {{ $em->links() }}
                        </div>
              <div class="form-group">
                                    <div class="col-lg-10" style=" text-align: right;">
                                       
                                       
                                   <button type="Submit" class="btn btn-primary">
                                            <span class="fa fa-plus"></span>
                                         <a href="/admin/emp_hoilday/add" class="btn btn-info">     <span> اضافة</span>
                                       </a> </button>
                                    </div>
                                </div>
            </div>
          </div>
        </div>
      </div>
@endsection

@section('js')
@endsection