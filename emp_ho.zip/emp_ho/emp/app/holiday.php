<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class holiday extends Model
{
    public function emp_holiday()
    {
        return $this->hasMany(emp_holiday::class,'holi_id','id');
         
    	
    }
}
