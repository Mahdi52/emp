<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Department extends Model
{
    public function emplo()
    {
        return $this->hasMany(emplo::class,'user_id','id');
         

    }
}
