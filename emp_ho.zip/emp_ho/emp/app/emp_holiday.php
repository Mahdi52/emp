<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class emp_holiday extends Model
{
    public function holiday()
    {
        return $this->belongsTo(holiday::class,'holi_id');
    }
}
