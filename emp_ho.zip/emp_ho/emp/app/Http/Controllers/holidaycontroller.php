<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\emplo;
use App\Department;
use App\emp_holiday;
use App\holiday;
use Validator;


class holidaycontroller extends Controller
{
    public function index()
    {
        $em = holiday::orderByDesc('id')->paginate('10');
        return view('admin.holiday.all', compact('em'));
    }
    public function addget()
    {
     // $categories = Department::all();
      return view('admin.holiday.add');
    }
    public function add(Request $request)
    {
  
        //input validation
        $validator = Validator::make($request->all(), [
            'type' => 'required',
            'time2' => 'required'
        ]);
        //return errors if if exist
        if ($validator->fails())
            return back()->withErrors($validator->errors())->withInput();
  
        //new object of news
        $holiday = new holiday();
  
        $holiday->type = $request->type;
        $holiday->time2 = $request->time2;
        //save it
        $holiday->save();
        return redirect('/admin/holiday');
  
    }
  
    public function categories()
    {
    }
  
    public function delete(holiday $news)
    {
        return view('admin.holiday.delete', compact('news'));
    }
  
    public function destroy(holiday $news)
    {
        $category->delete();
  
        return redirect('/admin/holiday');
    }
  
    public function edit(holiday $news)
    {
        return view('admin.holiday.edit', compact('news'));
    }
  
    public function update(holiday $news, Request $request)
    {
          //input validation
          $validator = Validator::make($request->all(), [
            'type' => 'required',
            'time2' => 'required'
        ]);
        //return errors if if exist
        if ($validator->fails())
            return back()->withErrors($validator->errors())->withInput();
  
        //new object of news
       
  
        $news->type = $request->type;
        $news->time2 = $request->time2;
        //update object
        $news->update();
  
        return redirect('/admin/holiday');
  
    }
}
