<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\emplo;
use App\Department;
use App\emp_holiday;
use App\holiday;
use Validator;

class emp_holidaycontroller extends Controller
{
    public function index()
  {
      $em = emp_holiday::orderByDesc('id')->paginate('10');
      return view('admin.emp_hoilday.all', compact('em'));
  }

  public function addNewsGet()
    {
        $categories = holiday::all();
        return view('admin.emp_hoilday.add', compact('categories'));
    }

    public function addNewsPost(Request $request)
    {

        //input validation
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'time1'  => 'required',
            'categories' => 'integer'
        ]);
        //return errors if if exist
        if ($validator->fails())
            return back()->withErrors($validator->errors())->withInput();

        //new object of news
        $emplo = new emp_holiday;

        $emplo->name = $request->name;
        $emplo->time1 = $request->time1;
        $emplo->holi_id = $request->categories;


        
       
       
        //save it
        $emplo->save();
        return redirect('/admin/emp_hoilday');

    }

    public function destroy(emp_holiday $news)
    {
        //delete image first
        
        $news->delete();

        return redirect('/admin/emp_hoilday');
    }  

    public function delete(emp_holiday $news)
    {
        return view('admin.emp_hoilday.delete', compact('news'));
    }



    public function edit(emp_holiday $emplo)
    {
        $categories = holiday::all();
        return view('admin.emp_hoilday.edit', compact('emplo', 'categories'));
    }




    public function update(emp_holiday $emplo, Request $request)
    {

        //input validation
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'time1'  => 'required',
            'categories' => 'integer'
        ]);
        //return errors if if exist
        if ($validator->fails())
            return back()->withErrors($validator->errors())->withInput();

        //new object of news
        

        $emplo->name = $request->name;
        $emplo->time1 = $request->time1;
        $emplo->holi_id = $request->categories;

      
        //update object
        $emplo->update();
        return redirect('/admin/emp_hoilday');

    }
}
