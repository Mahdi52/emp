<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Department;
use Validator;
class departmentcontroller extends Controller
{
    public function index()
  {
      $em = Department::orderByDesc('id')->paginate('10');
      return view('admin.Department.all', compact('em'));
  }

  public function add(Request $request)
  {

      //input validation
      $validator = Validator::make($request->all(), [
          'name' => 'required'
      ]);
      //return errors if if exist
      if ($validator->fails())
          return back()->withErrors($validator->errors())->withInput();

      //new object of news
      $category = new Department();

      $category->name = $request->name;
      //save it
      $category->save();
      return redirect('/admin/Department');

  }

  public function addget()
  {
    $categories = Department::all();
    return view('admin.Department.add');
  }

  public function delete(Department $category)
  {
      return view('admin.Department.delete', compact('category'));
  }

  public function destroy(Department $category)
  {
      $category->delete();

      return redirect('/admin/Department');
  }

  public function edit(Department $category)
  {
      return view('admin.Department.edit', compact('category'));
  }

  public function update(Department $category, Request $request)
  {
      //input validation
      $validator = Validator::make($request->all(), [
          'name' => 'required'
      ]);

      //return errors if exist
      if ($validator->fails())
          return back()->withErrors($validator->errors())->withInput();

      $category->name = $request->name;

      //update object
      $category->update();

      return redirect('/admin/Department');

  }
}
