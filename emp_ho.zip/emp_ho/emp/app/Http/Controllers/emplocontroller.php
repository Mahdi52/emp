<?php

namespace App\Http\Controllers;
use Session;
use Illuminate\Http\Request;
use App\emplo;
use App\Department;
use Validator;

class emplocontroller extends Controller
{
  public function index()
  {
      $em = emplo::orderByDesc('id')->paginate('10');
      return view('admin.emplo.all', compact('em'));
  }

  public function addNewsGet()
    {
        $categories = Department::all();
        return view('admin.emplo.add', compact('categories'));
    }

    public function addNewsPost(Request $request)
    {

        //input validation
        $validator = Validator::make($request->all(), [
            'name' => 'required',
            'age'  => 'required',
            'job' => 'required',
            'categories' => 'integer'
        ]);
        //return errors if if exist
        if ($validator->fails())
            return back()->withErrors($validator->errors())->withInput();

        //new object of news
        $emplo = new emplo;

        $emplo->name = $request->name;
        $emplo->age = $request->age;
        $emplo->job = $request->job;
        $emplo->user_id = $request->categories;


        
       
       
        //save it
        $emplo->save();
        return redirect('/admin/emplo');

    }

    public function destroy(emplo $news)
    {
        //delete image first
        
        $news->delete();

        return redirect('/admin/emplo');
    }  

    public function delete(emplo $news)
    {
        return view('admin.emplo.delete', compact('news'));
    }



    public function edit(emplo $emplo)
    {
        $categories = Department::all();
        return view('admin.emplo.edit', compact('emplo', 'categories'));
    }




    public function update(emplo $emplo, Request $request)
    {

        //input validation
        //input validation
        $validator = Validator::make($request->all(), [
          'name' => 'required',
          'age'  => 'required',
          'job' => 'required',
          'categories' => 'integer'
      ]);
      //return errors if if exist
      if ($validator->fails())
          return back()->withErrors($validator->errors())->withInput();

      //new object of news
      

      $emplo->name = $request->name;
      $emplo->age = $request->age;
      $emplo->job = $request->job;
      $emplo->user_id = $request->categories;

      
        //update object
        $emplo->update();
        return redirect('/admin/emplo');

    }
      }
    
    
