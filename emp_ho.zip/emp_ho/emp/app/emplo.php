<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class emplo extends Model
{
    public function Department()
    {
        
    	return $this->belongsTo(Department::class,'user_id');
    }
}
