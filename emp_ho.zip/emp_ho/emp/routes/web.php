<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/admin/emplo', 'emplocontroller@index')->middleware('auth');
Route::get('/admin/emplo/add', 'emplocontroller@addNewsGet')->middleware('auth');
Route::post('/admin/emplo/add', 'emplocontroller@addNewsPost')->middleware('auth');
Route::get('/admin/emplo/delete/{news}', 'emplocontroller@delete')->middleware('auth');
Route::post('/admin/emplo/delete/{news}', 'emplocontroller@destroy')->middleware('auth');
Route::get('/admin/emplo/edit/{emplo}', 'emplocontroller@edit')->middleware('auth');

Route::post('/admin/emplo/edit/{emplo}', 'emplocontroller@update')->middleware('auth');

//Route::get('/admin/emplo/add', 'emplocontroller@index')->middleware('auth');


Route::get('/admin/Department', 'departmentcontroller@index')->middleware('auth');

Route::get('/admin/Department/add', 'departmentcontroller@addget')->middleware('auth');
Route::post('/admin/Department/add', 'departmentcontroller@add')->middleware('auth');
Route::get('/admin/Department/delete/{category}', 'departmentcontroller@delete')->middleware('auth');
Route::post('/admin/Department/delete/{category}', 'departmentcontroller@destroy')->middleware('auth');
Route::get('/admin/Department/edit/{category}', 'departmentcontroller@edit')->middleware('auth');

Route::post('/admin/Department/edit/{category}', 'departmentcontroller@update')->middleware('auth');



///////////////
Route::get('/admin/holiday', 'holidaycontroller@index')->middleware('auth');
Route::get('/admin/holiday/add', 'holidaycontroller@addget')->middleware('auth');
Route::post('/admin/holiday/add', 'holidaycontroller@add')->middleware('auth');
Route::get('/admin/holiday/delete/{news}', 'holidaycontroller@delete')->middleware('auth');
Route::post('/admin/holiday/delete/{news}', 'holidaycontroller@destroy')->middleware('auth');
Route::get('/admin/holiday/edit/{news}', 'holidaycontroller@edit')->middleware('auth');

Route::post('/admin/holiday/edit/{news}', 'holidaycontroller@update')->middleware('auth');





////////////////////
Route::get('/admin/emp_hoilday', 'emp_holidaycontroller@index')->middleware('auth');
Route::get('/admin/emp_hoilday/add', 'emp_holidaycontroller@addNewsGet')->middleware('auth');
Route::post('/admin/emp_hoilday/add', 'emp_holidaycontroller@addNewsPost')->middleware('auth');
Route::get('/admin/emp_hoilday/delete/{news}', 'emp_holidaycontroller@delete')->middleware('auth');
Route::post('/admin/emp_hoilday/delete/{news}', 'emp_holidaycontroller@destroy')->middleware('auth');
Route::get('/admin/emp_hoilday/edit/{emplo}', 'emp_holidaycontroller@edit')->middleware('auth');

Route::post('/admin/emp_hoilday/edit/{emplo}', 'emp_holidaycontroller@update')->middleware('auth');

Route::get('/', function () {
    return view('/admin/emplo');
});

Auth::routes();

//Route::get('/home', 'HomeController@index')->name('home');
